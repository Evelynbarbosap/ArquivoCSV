
package lercsv;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LerCsv {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        String csvArquivo = "clientes.csv"; // meu arquivo
        BufferedReader conteudo = null; // inicia nulo
        String linha = ""; // cada linha representada por um string
        String csvSeparadorCampo = ";"; // separador
        
        try{
             conteudo = new BufferedReader(new FileReader(csvArquivo)); // os dados do cleitne no arquivo
            
            while((linha = conteudo.readLine()) != null){ //se o que estiver na linha não for nulo
                    String[] informacao = linha.split(csvSeparadorCampo); //informação éo que está em cada coluna
                    System.out.println("Nome : " + informacao[0] + " Idade: " + informacao[1] + " Email: " + informacao[2]);
                    
                   
            }
        } catch(FileNotFoundException e){ // se arquivo nao dor encontrado
            System.err.format("documento nao existente.\n");
        } catch(ArrayIndexOutOfBoundsException e){ // se colocar um index q n tem no conteudo da erro ou arquivo invalido 
            System.err.format("IndexOutOfBounds: \n" + e.getMessage());
        }catch(IOException e){//se é algum problema no disco
            System.out.println("IO Erro:\n" + e.getMessage()); 
        }finally{
            if(conteudo != null){ // se o conteudo processou tudo e n for nulo
                try{
                    conteudo.close(); // fecha arquivo para nao corromper
                }catch (IOException e){
                    System.out.println("IO Erro: \n"+ e.getMessage());
                }
            }
        }
    }
    
}
